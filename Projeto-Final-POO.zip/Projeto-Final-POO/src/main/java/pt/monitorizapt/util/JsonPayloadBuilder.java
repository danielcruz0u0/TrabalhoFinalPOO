package pt.monitorizapt.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

import pt.monitorizapt.domain.DadosSensor;
import pt.monitorizapt.domain.Sensor;

// used to round the numeric values sent in the payload
import java.math.BigDecimal;
import java.math.RoundingMode;

public class JsonPayloadBuilder {

    // gson instance used to convert objects to JSON
    private static final Gson GSON =
            new GsonBuilder().disableHtmlEscaping().create();

    // builds the MQTT JSON payload for a single sensor reading
    public String buildPayload(Sensor sensor, DadosSensor dados) {

        JsonObject objeto = new JsonObject();

        // fields required by the project specification
        objeto.addProperty("campus", sensor.getLocalizacao().descricao());
        objeto.addProperty("sensor", sensor.getIDUnico());
        objeto.addProperty("ID Unico", sensor.getIDUnico());
        objeto.addProperty("Owner", sensor.getOwner());
        objeto.addProperty("tipo", sensor.getTipo().tipoJson());

        // I round the value to 2 decimals before publishing
        objeto.addProperty("valor", arredondar(dados.valor()));

        objeto.addProperty("unidade", dados.unidade());
        objeto.addProperty("alerta", dados.alerta());
        objeto.addProperty("timestamp", dados.timestamp());

        // JSON without the hash field
        String semHash = GSON.toJson(objeto);

        // here I remove spaces before hashing the payload string
        String semEspacos = semHash.replace(" ", "");

        // hash is calculated using my hex implementation in HashUtil
        objeto.addProperty("hash_validacao",
                HashUtil.sha256Hex(semEspacos));

        // final JSON returned to MQTT publish
        return GSON.toJson(objeto);
    }

    // helper function to round values to 2 decimal places
    private double arredondar(double valor) {
        return BigDecimal
                .valueOf(valor)
                .setScale(2, RoundingMode.HALF_UP)
                .doubleValue();
    }
}
