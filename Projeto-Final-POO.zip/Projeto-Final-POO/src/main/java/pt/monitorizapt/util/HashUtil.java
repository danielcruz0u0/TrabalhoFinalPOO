package pt.monitorizapt.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public final class HashUtil {
    private static final char[] HEX_ARRAY = "0123456789abcdef".toCharArray();

    private HashUtil() {
    }

    public static String sha256Hex(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes(StandardCharsets.UTF_8));
            return toHex(hash);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 not available", e);
        }
    }

    private static String toHex(byte[] data) {
        char[] chars = new char[data.length * 2];
        for (int i = 0; i < data.length; i++) {
            int v = data[i] & 0xFF;
            chars[i * 2] = HEX_ARRAY[v >>> 4];
            chars[i * 2 + 1] = HEX_ARRAY[v & 0x0F];
        }
        return new String(chars);
    }
}



/* Este codigo segue o enunciado, mas o de cima é uma versao melhorada converte os bytes para hexadecimal
e devolve uma hash legível e correta, ja no enunciado o pedido nao seria o ideal e iria devolver valores errados.

package pt.monitorizapt.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

package pt.monitorizapt.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public final class HashUtil {

    private HashUtil() {
    }

    public static String normalizeJsonWithoutSpaces(String json) {
        if (json == null) {
            return "";
        }
        return json.replaceAll("\\s+", "");
    }

    public static String sha256Spec(String jsonWithoutSpaces) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(jsonWithoutSpaces.getBytes(StandardCharsets.UTF_8));
            return hashBytes.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 not available", e);
        }
    }

    public static String computeHashValidacao(String jsonRaw) {
        String jsonNoSpaces = normalizeJsonWithoutSpaces(jsonRaw);
        return sha256Spec(jsonNoSpaces);
    }
}

*/