package pt.monitorizapt.ui;

import pt.monitorizapt.domain.SensorLocalizacao;
import pt.monitorizapt.mqtt.MqttClientManager;
import pt.monitorizapt.service.SensorController;
import pt.monitorizapt.service.SensorSnapshot;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.concurrent.CompletableFuture;

// Main Swing window of the application (dashboard UI)
public class MonitorizaPTFrame extends JFrame {

    private final SensorController controller;
    private final MqttClientManager mqttClientManager;

    // table model that stores the sensor rows
    private final SensorTableModel tableModel = new SensorTableModel();

    // UI components
    private final JLabel estadoMqttLabel = new JLabel("Estado MQTT: VERMELHO");
    private final JButton testarBrokerButton = new JButton("TESTAR BROKER");
    private final JComboBox<SensorLocalizacao> localizacaoCombo = new JComboBox<>(SensorLocalizacao.values());
    private final JLabel intervaloLabel = new JLabel("Intervalo (ms):");
    private final JTextField intervaloField = new JTextField("3333", 6);
    private final JButton iniciarButton = new JButton("INICIAR");
    private final JButton pararButton = new JButton("PARAR");
    private final JButton limparLogsButton = new JButton("LIMPAR LOGS");
    private final JTextArea logArea = new JTextArea();

    public MonitorizaPTFrame(SensorController controller, MqttClientManager mqttClientManager) {
        super("MonitorizaPT - Sensores Ambientais v1.0");

        this.controller = controller;
        this.mqttClientManager = mqttClientManager;

        configurarJanela();
        registrarCallbacks();
    }

    // basic window setup (size, layout, panels...)
    private void configurarJanela() {

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLayout(new BorderLayout(10, 10));
        setLocationRelativeTo(null);

        add(criarPainelNorte(), BorderLayout.NORTH);
        add(criarTabela(), BorderLayout.CENTER);
        add(criarPainelSul(), BorderLayout.SOUTH);

        // log text box config
        logArea.setEditable(false);
        logArea.setLineWrap(true);
        logArea.setWrapStyleWord(true);
        logArea.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        // when window closes I stop sensors + MQTT
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                controller.shutdown();
            }
        });
    }

    // top panel with MQTT connection state + test button
    private JPanel criarPainelNorte() {

        JPanel painel = new JPanel(new BorderLayout(10, 0));

        estadoMqttLabel.setOpaque(true);
        estadoMqttLabel.setBackground(Color.RED.darker());
        estadoMqttLabel.setForeground(Color.WHITE);
        estadoMqttLabel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

        painel.add(estadoMqttLabel, BorderLayout.WEST);
        painel.add(testarBrokerButton, BorderLayout.EAST);

        return painel;
    }

    // center panel containing the JTable
    private JScrollPane criarTabela() {
        JTable tabela = new JTable(tableModel);
        tabela.setFillsViewportHeight(true);

        JScrollPane scrollPane = new JScrollPane(tabela);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        return scrollPane;
    }

    // bottom control panel + logs panel
    private JPanel criarPainelSul() {

        JPanel painelSul = new JPanel(new BorderLayout(10, 10));

        JPanel painelControlo = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));

        // controls to activate / stop a sensor
        painelControlo.add(localizacaoCombo);
        painelControlo.add(intervaloLabel);

        intervaloField.setPreferredSize(new Dimension(80, 24));
        painelControlo.add(intervaloField);

        painelControlo.add(iniciarButton);
        painelControlo.add(pararButton);
        painelControlo.add(limparLogsButton);

        painelSul.add(painelControlo, BorderLayout.NORTH);

        // logs area at the bottom
        JScrollPane scrollLogs = new JScrollPane(logArea);
        scrollLogs.setPreferredSize(new Dimension(100, 150));

        painelSul.add(scrollLogs, BorderLayout.CENTER);

        return painelSul;
    }

    // links UI events with controller + MQTT callbacks
    private void registrarCallbacks() {

        controller.registerSnapshotObserver(snapshot ->
                SwingUtilities.invokeLater(() -> atualizarTabela(snapshot)));

        controller.registerLogObserver(log ->
                SwingUtilities.invokeLater(() -> appendLog(log)));

        mqttClientManager.registerConnectionListener(conectado ->
                SwingUtilities.invokeLater(() -> atualizarEstado(conectado)));

        testarBrokerButton.addActionListener(event -> testarBroker());
        iniciarButton.addActionListener(event -> iniciarSensorSelecionado());
        pararButton.addActionListener(event -> pararSensorSelecionado());
        limparLogsButton.addActionListener(event -> logArea.setText(""));
    }

    private void atualizarTabela(SensorSnapshot snapshot) {
        tableModel.upsert(snapshot);
    }

    private void appendLog(String linha) {
        logArea.append(linha + System.lineSeparator());
        logArea.setCaretPosition(logArea.getDocument().getLength());
    }

    // updates MQTT connection indicator (green / red)
    private void atualizarEstado(boolean conectado) {
        if (conectado) {
            estadoMqttLabel.setText("Estado MQTT: VERDE");
            estadoMqttLabel.setBackground(new Color(0, 128, 0));
        } else {
            estadoMqttLabel.setText("Estado MQTT: VERMELHO");
            estadoMqttLabel.setBackground(Color.RED.darker());
        }
    }

    // tests connection asynchronously (so UI does not freeze)
    private void testarBroker() {
        testarBrokerButton.setEnabled(false);

        CompletableFuture<Boolean> resultado = mqttClientManager.testConnectionAsync();

        resultado.whenComplete((conectado, erro) ->
                SwingUtilities.invokeLater(() -> {

                    testarBrokerButton.setEnabled(true);

                    if (erro != null) {
                        appendLog("Falha ao testar broker: " + erro.getMessage());
                        atualizarEstado(false);
                    } else {
                        appendLog(conectado ? "Broker disponível" : "Broker indisponível");
                        atualizarEstado(conectado);
                    }
                }));
    }

    private void iniciarSensorSelecionado() {
        SensorLocalizacao localizacao = (SensorLocalizacao) localizacaoCombo.getSelectedItem();
        long intervalo = lerIntervalo();
        controller.ativarLocalizacao(localizacao, intervalo);
    }

    private void pararSensorSelecionado() {
        SensorLocalizacao localizacao = (SensorLocalizacao) localizacaoCombo.getSelectedItem();
        controller.desativarLocalizacao(localizacao);
    }

    // reads interval field (falls back to 3333 if invalid)
    private long lerIntervalo() {
        try {
            return Long.parseLong(intervaloField.getText().trim());
        } catch (NumberFormatException ex) {
            intervaloField.setText("3333");
            return 3333L;
        }
    }
}

// botao de test broker adicionado, porque muitas vezes ao abrir o trabalho nao funcionava os testes
// entao temos de esperar estar a ligado para depois sim testar