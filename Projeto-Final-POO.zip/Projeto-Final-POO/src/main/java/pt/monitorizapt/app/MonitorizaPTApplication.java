package pt.monitorizapt.app;

import pt.monitorizapt.mqtt.MqttClientManager;
import pt.monitorizapt.service.SensorController;
import pt.monitorizapt.ui.MonitorizaPTFrame;

import javax.swing.SwingUtilities;

public final class MonitorizaPTApplication {

    // small utility class, only used to start the program
    private MonitorizaPTApplication() {
    }

    public static void main(String[] args) {

        // I start the UI on the Swing thread (recommended for Swing apps)
        SwingUtilities.invokeLater(() -> {

            // default broker from the assignment
            // I can override it using -Dmonitorizapt.broker=<url>
            String brokerUrl = System.getProperty(
                    "monitorizapt.broker",
                    "tcp://172.237.103.61:1883"
            );

            // MQTT manager (handles publish and subscribe)
            MqttClientManager mqttClientManager = new MqttClientManager(brokerUrl);

            // controller that manages the sensors and updates
            SensorController controller = new SensorController(mqttClientManager);

            // main application window (Swing dashboard)
            MonitorizaPTFrame frame = new MonitorizaPTFrame(controller, mqttClientManager);

            // show the UI
            frame.setVisible(true);
        });
    }
}
