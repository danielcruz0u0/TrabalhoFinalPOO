package pt.monitorizapt.sensors;

import pt.monitorizapt.domain.DadosSensor;
import pt.monitorizapt.domain.SensorAbstrato;
import pt.monitorizapt.domain.SensorLocalizacao;
import pt.monitorizapt.domain.SensorTipo;
import pt.monitorizapt.mqtt.MqttClientManager;
import pt.monitorizapt.util.JsonPayloadBuilder;

import java.util.concurrent.ThreadLocalRandom;

// concrete implementation for the humidity sensor
public class SensorHumidade extends SensorAbstrato {

    public SensorHumidade(SensorLocalizacao localizacao,
                          JsonPayloadBuilder payloadBuilder,
                          MqttClientManager mqttClientManager) {

        // I pass the type + location to the base class
        super(SensorTipo.HUMIDADE, localizacao, payloadBuilder, mqttClientManager);
    }

    @Override
    protected DadosSensor gerarDadosEspecificos() {

        ThreadLocalRandom random = ThreadLocalRandom.current();

        // normal humidity range (simulated)
        double valor = random.nextDouble(45.0, 78.0);

        // I use a small probability to generate "weird" values on purpose
        double prob = random.nextDouble();

        if (prob < 0.10) {
            // very low spike
            valor = random.nextDouble(0.0, 15.0);
        } else if (prob < 0.20) {
            // very high spike
            valor = random.nextDouble(81.0, 95.0);
        }

        // alert when humidity goes above 80%
        boolean alerta = valor > 80.0;

        return new DadosSensor(
                valor,
                SensorTipo.HUMIDADE.unidadePadrao(),
                alerta,
                System.currentTimeMillis()
        );
    }
}
