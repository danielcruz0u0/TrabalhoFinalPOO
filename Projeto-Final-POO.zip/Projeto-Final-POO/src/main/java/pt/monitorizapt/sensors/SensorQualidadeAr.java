package pt.monitorizapt.sensors;

import pt.monitorizapt.domain.DadosSensor;
import pt.monitorizapt.domain.SensorAbstrato;
import pt.monitorizapt.domain.SensorLocalizacao;
import pt.monitorizapt.domain.SensorTipo;
import pt.monitorizapt.mqtt.MqttClientManager;
import pt.monitorizapt.util.JsonPayloadBuilder;

import java.util.concurrent.ThreadLocalRandom;

// sensor implementation for air quality (AQI)
public class SensorQualidadeAr extends SensorAbstrato {

    public SensorQualidadeAr(SensorLocalizacao localizacao,
                             JsonPayloadBuilder payloadBuilder,
                             MqttClientManager mqttClientManager) {

        // I pass the type + location to the base class
        super(SensorTipo.QUALIDADE_AR, localizacao, payloadBuilder, mqttClientManager);
    }

    @Override
    protected DadosSensor gerarDadosEspecificos() {

        ThreadLocalRandom random = ThreadLocalRandom.current();

        // normal AQI range that I use most of the time
        double valor = random.nextDouble(5.0, 45.0);

        // sometimes I generate strange values on purpose (assignment requirement)
        double prob = random.nextDouble();

        if (prob < 0.15) {
            // high pollution spike
            valor = random.nextDouble(51.0, 120.0);
        } else if (prob < 0.20) {
            // invalid / nonsense value (below zero)
            valor = random.nextDouble(-10.0, 0.0);
        }

        // alert when AQI goes above 50
        boolean alerta = valor > 50.0;

        return new DadosSensor(
                valor,
                SensorTipo.QUALIDADE_AR.unidadePadrao(),
                alerta,
                System.currentTimeMillis()
        );
    }
}
