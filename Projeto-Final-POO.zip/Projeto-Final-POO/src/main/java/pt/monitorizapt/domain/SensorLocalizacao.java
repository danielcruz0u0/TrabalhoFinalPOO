package pt.monitorizapt.domain;

/**
 * Enum with the fixed locations used in the project.
 * These are the same places listed in the assignment.
 */
public enum SensorLocalizacao {

    LISBOA_CAMPUS_IPLUSO("Lisboa - Campus IPLuso", "Lisboa_Campus_IPLuso"),
    LISBOA_BAIXA("Lisboa - Baixa", "Lisboa_Baixa"),
    PORTO_MATOSINHOS("Porto - Matosinhos", "Porto_Matosinhos"),
    COIMBRA_CENTRO("Coimbra - Centro", "Coimbra_Centro"),
    FARO_MARINA("Faro - Marina", "Faro_Marina"),
    BRAGA_SAMEIRO("Braga - Sameiro", "Braga_Sameiro"),
    EVORA_UNIVERSIDADE("Évora - Universidade", "Evora_Universidade");

    private final String descricao;
    private final String segmentoTopico;

    SensorLocalizacao(String descricao, String segmentoTopico) {
        this.descricao = descricao;
        this.segmentoTopico = segmentoTopico;
    }

    // text that I show in the UI combo box
    public String descricao() {
        return descricao;
    }

    // part of the MQTT topic name
    public String segmentoTopico() {
        return segmentoTopico;
    }

    // used to build the sensor unique ID (no spaces / upper case)
    public String idSegmento() {
        return segmentoTopico
                .replace("-", "_")
                .replace(" ", "_")
                .toUpperCase();
    }

    // topic where sensor data is published
    public String topicoDados() {
        return "envira/pt/sensores/dados/" + segmentoTopico;
    }

    // topic where sensor commands are received
    public String topicoComandos() {
        return "envira/pt/sensores/comandos/" + segmentoTopico;
    }

    @Override
    public String toString() {
        // when printed, I prefer to show the human-readable description
        return descricao;
    }
}
