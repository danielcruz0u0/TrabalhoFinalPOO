package pt.monitorizapt.domain;

/**
 * Enum with the three sensor types used in the project.
 * Each type has a default unit and a label for the UI.
 */
public enum SensorTipo {

    TEMPERATURA("temperatura", "Celsius", "Temperatura"),
    HUMIDADE("humidade", "%", "Humidade"),
    QUALIDADE_AR("qualidade_ar", "AQI", "Qualidade do Ar");

    private final String tipoJson;
    private final String unidadePadrao;
    private final String etiqueta;

    SensorTipo(String tipoJson, String unidadePadrao, String etiqueta) {
        this.tipoJson = tipoJson;
        this.unidadePadrao = unidadePadrao;
        this.etiqueta = etiqueta;
    }

    // value that I send in the JSON payload
    public String tipoJson() {
        return tipoJson;
    }

    // default unit for this sensor type
    public String unidadePadrao() {
        return unidadePadrao;
    }

    // text shown in the UI table
    public String etiqueta() {
        return etiqueta;
    }
}
