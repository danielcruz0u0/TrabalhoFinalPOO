package pt.monitorizapt.domain;

/**
 * Listener that is called every time a sensor sends data.
 * I use this mainly to update the UI and logs.
 */
@FunctionalInterface
public interface SensorUpdateListener {

    // sensor -> the sensor that produced the data
    // dados -> the generated reading
    // jsonPayload -> final JSON string that was published
    void onDadosPublicados(Sensor sensor, DadosSensor dados, String jsonPayload);
}
