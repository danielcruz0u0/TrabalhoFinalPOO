package pt.monitorizapt.domain;

/**
 * Immutable container for a sensor reading.
 * I use a Java record here because the values do not change after creation.
 */
public record DadosSensor(double valor, String unidade, boolean alerta, long timestamp) {

    // returns a small text that I use later in the UI table
    public String alertaTexto() {
        return alerta ? "ALERTA" : "OK";
    }
}
