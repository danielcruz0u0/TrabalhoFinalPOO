package pt.monitorizapt.domain;

import java.util.List;
import java.util.Locale;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

import pt.monitorizapt.mqtt.MqttClientManager;
import pt.monitorizapt.util.JsonPayloadBuilder;

// abstract base class for all sensors (shared behaviour)
public abstract class SensorAbstrato implements Sensor, Runnable {

    // fixed interval from the assignment (3333 ms)
    private static final long INTERVALO_PADRAO = 3333L;

    // owner string with my name + student number
    private static final String OWNER_IDENTIFICADOR = "Daniel_Cruz_a22500003";

    private static final Gson GSON = new Gson();

    private final SensorTipo tipo;
    private final SensorLocalizacao localizacaoFixa;
    private final JsonPayloadBuilder payloadBuilder;
    private final MqttClientManager mqttClientManager;

    // listeners used by the UI to refresh values
    private final List<SensorUpdateListener> listeners = new CopyOnWriteArrayList<>();

    // flag to control thread lifecycle
    private final AtomicBoolean loopAtivo = new AtomicBoolean(false);

    // true only when sensor is enabled
    private volatile boolean ativo;

    // assignment requires the interval to be exactly 3333ms
    private volatile long intervaloMillis = INTERVALO_PADRAO;

    private volatile DadosSensor ultimaLeitura;
    private Thread worker;

    protected SensorAbstrato(
            SensorTipo tipo,
            SensorLocalizacao localizacaoFixa,
            JsonPayloadBuilder payloadBuilder,
            MqttClientManager mqttClientManager) {

        this.tipo = tipo;
        this.localizacaoFixa = localizacaoFixa;
        this.payloadBuilder = payloadBuilder;
        this.mqttClientManager = mqttClientManager;
    }

    // implemented in concrete sensor classes (temperature, humidity, etc.)
    protected abstract DadosSensor gerarDadosEspecificos();

    @Override
    public final DadosSensor lerDados() {
        // here I generate a new dummy sensor reading
        ultimaLeitura = gerarDadosEspecificos();
        return ultimaLeitura;
    }

    @Override
    public final void publicarMQTT(String json) {
        if (mqttClientManager != null) {
            mqttClientManager.publish(localizacaoFixa.topicoDados(), json);
        }
    }

    @Override
    public void processarComando(String comandoJSON) {
        try {
            JsonObject objeto = GSON.fromJson(comandoJSON, JsonObject.class);

            if (objeto == null || !objeto.has("acao")) {
                return;
            }

            // command field (ATIVAR / DESATIVAR)
            String acao = objeto.get("acao").getAsString().toUpperCase(Locale.ROOT);

            switch (acao) {
                case "ATIVAR" -> ativar();
                case "DESATIVAR" -> desativar();
                default -> { /* no-op */ }
            }

            // assignment mentions "intervalo", but I keep 3333ms fixed
            if (objeto.has("intervalo")) {
                setIntervaloMillis(objeto.get("intervalo").getAsLong());
            }

        } catch (JsonParseException | IllegalStateException ignored) {
            // if command JSON is invalid, I just ignore it
        }
    }

    @Override
    public final String getOwner() {
        return OWNER_IDENTIFICADOR;
    }

    @Override
    public final SensorTipo getTipo() {
        return tipo;
    }

    @Override
    public final SensorLocalizacao getLocalizacao() {
        return localizacaoFixa;
    }

    @Override
    public final boolean isAtivo() {
        return ativo;
    }

    @Override
    public final void ativar() {
        // sensor becomes active (it will start publishing)
        this.ativo = true;
    }

    @Override
    public final void desativar() {
        // sensor keeps the loop running but stops sending data
        this.ativo = false;
    }

    @Override
    public final long getIntervaloMillis() {
        return intervaloMillis;
    }

    @Override
    public final void setIntervaloMillis(long intervaloMillis) {
        // assignment requires exactly 3333ms, so I keep it fixed
        this.intervaloMillis = INTERVALO_PADRAO;
    }

    @Override
    public final void registrarListener(SensorUpdateListener listener) {
        listeners.add(listener);
    }

    @Override
    public final void removerListener(SensorUpdateListener listener) {
        listeners.remove(listener);
    }

    @Override
    public void iniciar() {
        // only create the thread once
        if (loopAtivo.compareAndSet(false, true)) {
            worker = new Thread(this, getIDUnico() + "-loop");
            worker.setDaemon(true);
            worker.start();
        }
    }

    @Override
    public void desligar() {
        // stops the worker thread safely
        loopAtivo.set(false);

        if (worker != null) {
            worker.interrupt();
        }
    }

    @Override
    public String getIDUnico() {
        // id format required in the assignment
        return "PT-SENSOR-" + localizacaoFixa.idSegmento();
    }

    @Override
    public void run() {

        // sensor loop (while(true) + sleep)
        while (true) {

            if (!loopAtivo.get()) {
                break;
            }

            try {
                // only publish data if the sensor is active
                if (ativo) {
                    DadosSensor leitura = lerDados();
                    String payload = payloadBuilder.buildPayload(this, leitura);
                    publicarMQTT(payload);
                    notificar(leitura, payload);
                }

                // fixed interval from the assignment
                Thread.sleep(intervaloMillis);

            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
                break;
            } catch (Exception ex) {
                // if one reading fails, the loop keeps running
            }
        }
    }

    protected final DadosSensor ultimaLeitura() {
        return ultimaLeitura;
    }

    protected final void notificar(DadosSensor dados, String payload) {
        listeners.forEach(listener ->
                listener.onDadosPublicados(this, dados, payload));
    }
}
