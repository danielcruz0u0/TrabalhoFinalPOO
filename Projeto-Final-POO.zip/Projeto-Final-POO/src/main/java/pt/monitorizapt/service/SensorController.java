package pt.monitorizapt.service;

import pt.monitorizapt.domain.DadosSensor;
import pt.monitorizapt.domain.Sensor;
import pt.monitorizapt.domain.SensorAbstrato;
import pt.monitorizapt.domain.SensorLocalizacao;
import pt.monitorizapt.domain.SensorTipo;
import pt.monitorizapt.domain.SensorUpdateListener;
import pt.monitorizapt.mqtt.MqttClientManager;
import pt.monitorizapt.sensors.SensorHumidade;
import pt.monitorizapt.sensors.SensorQualidadeAr;
import pt.monitorizapt.sensors.SensorTemperatura;
import pt.monitorizapt.util.JsonPayloadBuilder;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

// controller that manages all sensors and connects them to MQTT + UI
public class SensorController {

    // formatter used for log messages in the UI
    private static final DateTimeFormatter LOG_FORMATTER =
            DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss")
                    .withZone(ZoneId.systemDefault());

    // one sensor per location (defined in the assignment)
    private final Map<SensorLocalizacao, SensorAbstrato> sensoresPorLocalizacao =
            new EnumMap<>(SensorLocalizacao.class);

    // observers used by the UI to refresh the table
    private final List<Consumer<SensorSnapshot>> snapshotObservers = new CopyOnWriteArrayList<>();

    // observers used to print log lines in the log area
    private final List<Consumer<String>> logObservers = new CopyOnWriteArrayList<>();

    private final JsonPayloadBuilder payloadBuilder = new JsonPayloadBuilder();
    private final MqttClientManager mqttClientManager;

    public SensorController(MqttClientManager mqttClientManager) {

        this.mqttClientManager = mqttClientManager;

        // creates the 7 sensors and registers listeners
        criarSensores();

        // start sensor threads (loop runs, but only publishes when active)
        sensoresPorLocalizacao.values().forEach(Sensor::iniciar);

        // subscribe MQTT commands for each location
        for (SensorLocalizacao localizacao : SensorLocalizacao.values()) {
            mqttClientManager.registerCommandHandler(
                    localizacao,
                    comando -> processarComandoRemoto(localizacao, comando)
            );
        }

        // connect to broker in background
        mqttClientManager.connectAsync();
    }

    // creates all sensors and maps them to locations
    private void criarSensores() {
        for (SensorLocalizacao localizacao : SensorLocalizacao.values()) {
            SensorAbstrato sensor = criarSensorPorLocalizacao(localizacao);
            sensor.registrarListener(criarListener());
            sensoresPorLocalizacao.put(localizacao, sensor);
        }
    }

    // chooses the correct type based on the location
    private SensorAbstrato criarSensorPorLocalizacao(SensorLocalizacao localizacao) {
        return switch (localizacao) {
            case LISBOA_CAMPUS_IPLUSO, COIMBRA_CENTRO, EVORA_UNIVERSIDADE ->
                    new SensorTemperatura(localizacao, payloadBuilder, mqttClientManager);

            case LISBOA_BAIXA, FARO_MARINA ->
                    new SensorHumidade(localizacao, payloadBuilder, mqttClientManager);

            case PORTO_MATOSINHOS, BRAGA_SAMEIRO ->
                    new SensorQualidadeAr(localizacao, payloadBuilder, mqttClientManager);
        };
    }

    // listener called every time a payload is published
    private SensorUpdateListener criarListener() {
        return (sensor, dados, payload) -> {

            // I create a snapshot for the UI table
            SensorSnapshot snapshot = new SensorSnapshot(
                    sensor.getIDUnico(),
                    sensor.getLocalizacao().descricao(),
                    sensor.getTipo(),
                    dados.valor(),
                    dados.unidade(),
                    dados.alerta(),
                    dados.timestamp()
            );

            snapshotObservers.forEach(observer -> observer.accept(snapshot));

            // simple log entry when a sensor publishes
            log(String.format(
                    "Sensor %s publicou %s",
                    sensor.getIDUnico(),
                    formatValor(sensor.getTipo(), dados)
            ));
        };
    }

    public void registerSnapshotObserver(Consumer<SensorSnapshot> observer) {
        snapshotObservers.add(observer);
    }

    public void registerLogObserver(Consumer<String> observer) {
        logObservers.add(observer);
    }

    // activates a sensor (interval is always kept as 3333ms inside the sensor)
    public void ativarLocalizacao(SensorLocalizacao localizacao, long intervaloMillis) {
        SensorAbstrato sensor = sensoresPorLocalizacao.get(localizacao);
        if (sensor == null) {
            return;
        }

        sensor.setIntervaloMillis(intervaloMillis);
        sensor.ativar();

        log(String.format(
                "Sensor %s ativado (intervalo %d ms)",
                sensor.getIDUnico(),
                sensor.getIntervaloMillis()
        ));
    }

    // stops publishing data (loop thread stays running)
    public void desativarLocalizacao(SensorLocalizacao localizacao) {
        SensorAbstrato sensor = sensoresPorLocalizacao.get(localizacao);
        if (sensor == null) {
            return;
        }

        sensor.desativar();
        log(String.format("Sensor %s desativado", sensor.getIDUnico()));
    }

    // applies incoming MQTT command to the correct sensor
    private void processarComandoRemoto(SensorLocalizacao localizacao, String comandoJson) {
        SensorAbstrato sensor = sensoresPorLocalizacao.get(localizacao);
        if (sensor == null) {
            return;
        }

        sensor.processarComando(comandoJson);

        log(String.format(
                "Comando MQTT aplicado a %s: %s",
                sensor.getIDUnico(),
                comandoJson
        ));
    }

    // writes a formatted log line to all observers
    private void log(String mensagem) {
        String linha = LOG_FORMATTER.format(Instant.now()) + " [INFO] " + mensagem;
        logObservers.forEach(observer -> observer.accept(linha));
    }

    // formats value depending on sensor type (for UI log)
    private String formatValor(SensorTipo tipo, DadosSensor dados) {
        return switch (tipo) {
            case TEMPERATURA -> String.format("%.2f\u00B0C", dados.valor());
            case HUMIDADE -> String.format("%.2f%%", dados.valor());
            case QUALIDADE_AR -> String.format("%.2f AQI", dados.valor());
        };
    }

    // called when closing the program
    public void shutdown() {
        sensoresPorLocalizacao.values().forEach(Sensor::desligar);
        mqttClientManager.shutdown();
    }
}
