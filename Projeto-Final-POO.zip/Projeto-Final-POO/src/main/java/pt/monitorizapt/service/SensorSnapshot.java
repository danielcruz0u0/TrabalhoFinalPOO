package pt.monitorizapt.service;

import pt.monitorizapt.domain.SensorTipo;

// small data object used by the UI to show sensor values in the table
public record SensorSnapshot(String id,
                             String localizacao,
                             SensorTipo tipo,
                             double valor,
                             String unidade,
                             boolean alerta,
                             long timestamp) {

    // helper method to format value + unit
    public String valorFormatado() {
        return String.format("%.2f %s", valor, unidade);
    }
}
